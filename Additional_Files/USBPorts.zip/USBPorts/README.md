# About `USBPorts` Package 

The USBPorts kexts included in this package are optional since my EFI contains `SSDT-PORTS.aml` which handdles USB Port mapping via ACPI which is completely independent of the used macOS version - it just works, always!

The USBPorts kexts asre only included for user who want to change to USB Port mapping but don't know how to do it in ACPI.

## About included Files
- 5 Variants of USBPorts. The all contain the same USB Port Mappings just different `model` identifiers so they work for the corresponding SMBIOS. Works in standalone. Can be modified in Hackintool
	- **USBPorts_iMac191** &rarr; for iMac19,1
	- **USBPorts_iMac201** &rarr; for iMac20,1
	- **USBPorts_iMac202** &rarr; for iMac20,2
	- **USBPorts_iMacPro1,1** &rarr; for iMacPro1,1
	- **USBPorts_MacPro7,1** &rarr; for MacPro7,1
- **Port Mapping List**: Shows the current mapping.

**NOTE**: I think you could just list more `models` in the property, but I am uncertain, how to device the entries (comma ore semicolon). That's why I created seperate kexts instead.

## Install Instructions

If you want to use the `USBPorts.kext` instead of `SSDT-PORTS.aml`, do the following:

1. Mount your ESP
2. Open your config with OCAT or ProperTree
3. Select the USBPorts.kext corresponding to the SMBIOS you are using
4. Add it to your EFI/OC/Kexts folder and config and enable it
5. Disable `ACPI/Add/SSDT-PORTS.aml`
6. Disabled `ACPI/Delete/Drop OEM USB Port Map (xh_cmsd4)`
7. Save and reboot

