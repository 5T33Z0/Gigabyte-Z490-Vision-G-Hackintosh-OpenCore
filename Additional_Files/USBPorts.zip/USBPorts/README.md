# About `USBPorts` Package 

The files included in this package (USBPorts.kext and ACPI Tables) are optional since the USB ports in my EFI are mapped via `SSDT-PORTS.aml` already.

They are only included if you want to change to USB Port mapping but don't know how to do it in ACPI.

## About included Files

- **SSDT-UIAC.aml**: **U**SB **I**nject **A**ll **C**orrrection Table – use this alongside `USBInject.all.kext` if you are using it (not recommeneded).
- **USBPorts_iMac202**: contains USB Port Mappings for iMac20,2 SMBIOS. Works in standalone. Can be modified in Hackintool. Disable `SSDT-PORTS.aml` before using it.
- **Port Mapping List**: Shows the current mapping.